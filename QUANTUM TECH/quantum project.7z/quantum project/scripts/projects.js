function projectspage(){
    //you can change what happens when the project button is clicked here
    document.getElementById('projectspage').click();
}