//This script file executes scripts present across all pages like the sign up script

function signup_page(){
    //window.open("signup.html");
    document.getElementById('signup').click();
}
